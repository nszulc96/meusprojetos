using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmDelFunc : Form
    {
        public frmDelFunc()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter DelFunc = new DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter();
            dgvDelFunc.DataSource = DelFunc.ConsultarFuncion�rio();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
           

            DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter DelFunc = new DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter();
            short codigo = Convert.ToInt16(dgvDelFunc.CurrentRow.Cells[0].Value);
            DelFunc.SP_DELETAR_FUNCIONARIO(codigo);
            dgvDelFunc.DataSource = DelFunc.ConsultarFuncion�rio();
            MessageBox.Show("Deletado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}