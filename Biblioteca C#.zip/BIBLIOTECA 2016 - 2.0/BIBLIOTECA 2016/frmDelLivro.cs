using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmDelLivro : Form
    {
        public frmDelLivro()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.LivroTableAdapter Livro = new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            dgvDelLivro.DataSource = Livro.SP_CONSULTA_LIVRO();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            
            DataSetBibliotecaTableAdapters.LivroTableAdapter DelLivro = new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            short codigo = Convert.ToInt16(dgvDelLivro.CurrentRow.Cells[0].Value);
            DelLivro.SP_DELETAR_LIVRO(codigo);
            dgvDelLivro.DataSource = DelLivro.SP_CONSULTA_LIVRO();
            MessageBox.Show("Deletado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);


        }
    }
}