using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmAlterarFunc : Form
    {
        public frmAlterarFunc()
        {
            InitializeComponent();
        }

        private void btnEscolher_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao funcion�rio carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtEmail.Clear();
            mskCPF.Clear();
            txtSetor.Clear();
            if (picImagem.Image != null)
            {
                picImagem.Image.Dispose();
                picImagem.Image = null;
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            

            DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter Func =
                new DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter();

            Func.SP_ALTERAR_FUNCIONARIO(
                Convert.ToInt16(txtCod.Text),
                txtNome.Text,
                txtEmail.Text,
                mskCPF.Text,
                txtSetor.Text,
                picImagem.ImageLocation);
            MessageBox.Show("Alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            MessageBox.Show("Fa�a uma nova consulta para ver o resultado", "Consulta", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

        }
    }
}