using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmAlterarCliente : Form
    {
        public frmAlterarCliente()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            // DataSetGameTableAdapters.TB_GAMETableAdapter taGame =
            //   new DataSetGameTableAdapters.TB_GAMETableAdapter();
            //PARA CARREGAR O DATAGRID, USA-SE A PROPRIEDADE DATA
            //dgvGames.DataSource = taGame.SP_CONSULTAR_GAMES();

            DataSetBibliotecaTableAdapters.ClienteTableAdapter Cliente = new
                DataSetBibliotecaTableAdapters.ClienteTableAdapter();
            dgvAlterarCliente.DataSource = Cliente.SP_CONSULTA_CLIENTE();

            

          
            
        }

        private void frmAlterarCliente_Load(object sender, EventArgs e)
        {
        
        }

        private void btnAlterarCliente_Click(object sender, EventArgs e)
        {
            //frmAlterarGame alt = new frmAlterarGame();
            //MOVER OS CAMPOS DA LINHA ESCOLHIDA PARA A TELA DE ALTERAR
            //MUITO IMPORTANTE
            //IR NO DESIGN DO FORM DE ALTERAR E TROCAR OS 
            //DA PROPRIEDADE MODIFIERS PARA PUBLIC
            //alt.txtCodigo.Text =
            //dgvGames.CurrentRow.Cells[0].Value.ToString();
            //alt.txtNome.Text =
            //dgvGames.CurrentRow.Cells[1].Value.ToString();
            //alt.cboGenero.Text =
            //dgvGames.CurrentRow.Cells[2].Value.ToString();
            //alt.cboPlataforma.Text =
            //dgvGames.CurrentRow.Cells[3].Value.ToString();
            //alt.numJogadores.Text =
            //dgvGames.CurrentRow.Cells[4].Value.ToString();
            //alt.numQuantidade.Text =
            //dgvGames.CurrentRow.Cells[5].Value.ToString();
            //alt.mskValor.Text =
            //dgvGames.CurrentRow.Cells[6].Value.ToString();
            //alt.picGame.ImageLocation =
            //dgvGames.CurrentRow.Cells[7].Value.ToString();   
            //alt.Show();
            frmAlterarCliente alt = new frmAlterarCliente();
            
            


        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            //DataSetGameTableAdapters.TB_GAMETableAdapter taGame =
            // new DataSetGameTableAdapters.TB_GAMETableAdapter();
            //taGame.SP_ALTERAR_GAME(
            // Convert.ToInt16(txtCodigo.Text),
            //txtNome.Text,
            // cboGenero.Text,
            //cboPlataforma.Text,
            //Convert.ToInt16(numJogadores.Value),
            //Convert.ToInt16(numQuantidade.Value),
            //Convert.ToDecimal(mskValor.Text),
            //picGame.ImageLocation,
            // "Descri��o depois colocar");
            // MessageBox.Show("Alterado com sucesso!");
            // MessageBox.Show("Fa�a uma nova consulta para ver o resultado.");

            DataSetBibliotecaTableAdapters.ClienteTableAdapter Cliente =
                new DataSetBibliotecaTableAdapters.ClienteTableAdapter();
            Cliente.SP_ALTERAR_CLIENTE(
                Convert.ToInt16(txtCodigo.Text),
                txtNome.Text,
                mskTelefone.Text,
                mskCelular.Text,
                txtEndereco.Text,
                txtEmail.Text,
                mskCPF.Text,
                picImagem.ImageLocation);
            MessageBox.Show("Alterado com sucesso!", "Altera��o", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            MessageBox.Show("Fa�a uma nova pesquisa para ver o resultado.", "Consulta", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            mskTelefone.Clear();
            mskCelular.Clear();
            txtEndereco.Clear();
            txtEmail.Clear();
            mskCPF.Clear();
            if (picImagem.Image != null)
            {
                picImagem.Image.Dispose();
                picImagem.Image = null;
            }
        }

        private void btnEscolher_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao cliente carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.ClienteTableAdapter Cliente = new
              DataSetBibliotecaTableAdapters.ClienteTableAdapter();
            dgvAlterarCliente.DataSource = Cliente.SP_CONSULTA_CLIENTE();


        }
    }
    }

