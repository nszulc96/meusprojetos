using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmAlterarLivro : Form
    {
        public frmAlterarLivro()
        {
            InitializeComponent();
        }

        private void btnEscolher_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao livro carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtEditora.Clear();
            txtAutor.Clear();
            cboCategoria.Items.Clear();
            mskPreco.Clear();
            if (picImagem.Image != null)
            {
                picImagem.Image.Dispose();
                picImagem.Image = null;
            }
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            // DataSetBibliotecaTableAdapters.EmpLivroTableAdapter Emp =
            // new DataSetBibliotecaTableAdapters.EmpLivroTableAdapter();
            // Emp.SP_ALTERAR_EMPLIVRO(
            // Convert.ToInt16(txtCodigo.Text),
            // txtNome.Text,
            // txtEditora.Text,
            // txtNomeCliente.Text,
            // Convert.ToDateTime(mskData1.Text),
            // txtFunc.Text,
            // Convert.ToDateTime(mskData2.Text),
            //txtObs.Text,
            // picImagem.ImageLocation);
            // MessageBox.Show("Alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            // MessageBox.Show("Fa�a uma nova consulta para ver o resultado", "Consulta", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

            DataSetBibliotecaTableAdapters.LivroTableAdapter Livro =
                new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            Livro.SP_ALTERAR_LIVRO(
                Convert.ToInt16(txtCodigo.Text),
                txtNome.Text,
                txtEditora.Text,
                txtAutor.Text,
                cboCategoria.Text,
                Convert.ToDecimal(mskPreco.Text),
                picImagem.ImageLocation);
            MessageBox.Show("Alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            MessageBox.Show("Fa�a uma nova consulta para ver o resultado", "Consulta", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.LivroTableAdapter Livro =
               new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            dgvConsultarLivros.DataSource = Livro.SP_CONSULTA_LIVRO();
        }
    }
}