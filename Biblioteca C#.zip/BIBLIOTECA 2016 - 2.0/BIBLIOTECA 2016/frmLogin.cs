﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            
            
            


        }

        private void btnLogar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.USUARIOSTableAdapter taUsuer = new DataSetBibliotecaTableAdapters.USUARIOSTableAdapter();

            //CONTAR A QTD DE LINHAS Q ESSA CONSULTA RETORNOU


            if (taUsuer.VERIFICAR_SENHA(txtUsuario.Text, txtSenha.Text).Rows.Count > 0)
            {
                frmPrincipal pri = new frmPrincipal();

                string nivel = taUsuer.VERIFICAR_SENHA(txtUsuario.Text, txtSenha.Text).Rows[0].ItemArray[1].ToString();
                if (nivel == "ADM")
                {
                    pri.TSMIDel.Enabled = true;
                }
                else
                {
                    pri.TSMIDel.Enabled = false;
                }
                txtSenha.Text = "";
                pri.Show();


            }
            else
            {
                MessageBox.Show("Senha Errada!","Erro",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }


        }
    }
}
