﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
  
    public partial class frmPesquisaClienteEmpLivro : Form
    {
        public frmCadEmprLivro cad;
        public frmPesquisaClienteEmpLivro()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.ClienteTableAdapter cli = new
            DataSetBibliotecaTableAdapters.ClienteTableAdapter();
            dgvConsultarClientes.DataSource = cli.SelecionaCPF(mskCPF.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //alt.txtCodigo.Text = dgvConsultarLivro.CurrentRow.Cells[0].Value.ToString();

            cad.txtNomeCliente.Text = dgvConsultarClientes.CurrentRow.Cells[1].Value.ToString();
            MessageBox.Show("Escolhido!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);



            cad.Show();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.ClienteTableAdapter cli = new DataSetBibliotecaTableAdapters.ClienteTableAdapter();
            dgvConsultarClientes.DataSource = cli.SP_CONSULTA_CLIENTE();
        }
    }
}
