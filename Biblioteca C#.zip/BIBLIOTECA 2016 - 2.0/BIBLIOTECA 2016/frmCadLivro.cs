using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmCadLivro : Form
    {
        public frmCadLivro()
        {
            InitializeComponent();
        }

        private void btnEscolher_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao livro carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void picImagem_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao livro carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtEditora.Clear();
            txtAutor.Clear();
            cboCategoria.Items.Clear();
            mskPreco.Clear();
            if (picImagem.Image != null)
            {
                picImagem.Image.Dispose();
                picImagem.Image = null;
            }

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            //DataSetGameTableAdapters.FUNCIONARIOTableAdapter Func = new DataSetGameTableAdapters.FUNCIONARIOTableAdapter();
            //Func.SP_INSERIR_FUNCIONARIO(
            //mskCPF.Text,
            //txtNome.Text,
            //Convert.ToDateTime(mskData.Text),
            //Convert.ToDateTime(dtpDataAdm.Text),
            //cboCargo.Text);
            //MessageBox.Show("Cadastrado com Sucesso");

            DataSetBibliotecaTableAdapters.LivroTableAdapter Livro =
                new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            Livro.SP_INSERE_LIVRO(
                txtNome.Text,
                txtEditora.Text,
                txtAutor.Text,
                cboCategoria.Text,
                Convert.ToDecimal(mskPreco.Text),
                picImagem.ImageLocation);
            MessageBox.Show("Cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
    }
}