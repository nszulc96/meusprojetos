using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmConsEmprestimo : Form
    {
        public frmConsEmprestimo()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            

            DataSetBibliotecaTableAdapters.EmpLivroTableAdapter Emp =
                new DataSetBibliotecaTableAdapters.EmpLivroTableAdapter();
            dgvConsultarEmprestimo.DataSource = Emp.SP_CONSULTA_EMPLIVRO();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            frmAlterarEmp alt = new frmAlterarEmp();
            alt.txtCodigo.Text =
                dgvConsultarEmprestimo.CurrentRow.Cells[0].Value.ToString();
            alt.txtNome.Text =
                dgvConsultarEmprestimo.CurrentRow.Cells[1].Value.ToString();
            alt.txtEditora.Text =
                dgvConsultarEmprestimo.CurrentRow.Cells[2].Value.ToString();
            alt.txtNomeCliente.Text =
                dgvConsultarEmprestimo.CurrentRow.Cells[3].Value.ToString();
            alt.mskData1.Text =
                dgvConsultarEmprestimo.CurrentRow.Cells[4].Value.ToString();
            alt.txtFunc.Text =
                dgvConsultarEmprestimo.CurrentRow.Cells[5].Value.ToString();
            alt.mskData2.Text =
                dgvConsultarEmprestimo.CurrentRow.Cells[6].Value.ToString();
            alt.txtObs.Text =
                dgvConsultarEmprestimo.CurrentRow.Cells[7].Value.ToString();
            alt.picImagem.ImageLocation =
                dgvConsultarEmprestimo.CurrentRow.Cells[8].Value.ToString();
            alt.Show();
            




        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.EmpLivroTableAdapter Emp =
                new DataSetBibliotecaTableAdapters.EmpLivroTableAdapter();
            dgvConsultarEmprestimo.DataSource = Emp.SP_CONSULTA_EMPLIVRO();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            

            DataSetBibliotecaTableAdapters.EmpLivroTableAdapter Nome = new DataSetBibliotecaTableAdapters.EmpLivroTableAdapter();
            dgvConsultarEmprestimo.DataSource = Nome.SelecionaNome(txtNome.Text);
        }
    }
}