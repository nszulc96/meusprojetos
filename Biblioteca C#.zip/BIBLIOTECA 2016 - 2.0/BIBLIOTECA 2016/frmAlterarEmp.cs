using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmAlterarEmp : Form
    {
        public frmAlterarEmp()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.EmpLivroTableAdapter Emp = new DataSetBibliotecaTableAdapters.EmpLivroTableAdapter();
            Emp.SP_CONSULTA_EMPLIVRO();
            dgvAlterarEmp.DataSource = Emp.SP_CONSULTA_EMPLIVRO();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            //DataSetGameTableAdapters.TB_GAMETableAdapter taGame =
            // new DataSetGameTableAdapters.TB_GAMETableAdapter();
            //taGame.SP_ALTERAR_GAME(
            // Convert.ToInt16(txtCodigo.Text),
            //txtNome.Text,
            // cboGenero.Text,
            //cboPlataforma.Text,
            //Convert.ToInt16(numJogadores.Value),
            //Convert.ToInt16(numQuantidade.Value),
            //Convert.ToDecimal(mskValor.Text),
            //picGame.ImageLocation,
            // "Descri��o depois colocar");
            // MessageBox.Show("Alterado com sucesso!");
            // MessageBox.Show("Fa�a uma nova consulta para ver o resultado.");

            DataSetBibliotecaTableAdapters.EmpLivroTableAdapter Emp =
                new DataSetBibliotecaTableAdapters.EmpLivroTableAdapter();
            Emp.SP_ALTERAR_EMPLIVRO(
                Convert.ToInt16(txtCodigo.Text),
                txtNome.Text,
                txtEditora.Text,
                txtNomeCliente.Text,
                Convert.ToDateTime(mskData1.Text),
                txtFunc.Text,
                Convert.ToDateTime(mskData2.Text),
                txtObs.Text,
                picImagem.ImageLocation);
            MessageBox.Show("Alterado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            MessageBox.Show("Fa�a uma nova consulta para ver o resultado", "Consulta", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnEscolher_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao livro carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtEditora.Clear();
            mskData1.Clear();
            txtFunc.Clear();
            mskData2.Clear();
            txtObs.Clear();
            if (picImagem.Image != null)
            {
                picImagem.Image.Dispose();
                picImagem.Image = null;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //frmAlterarGame alt = new frmAlterarGame();
            //MOVER OS CAMPOS DA LINHA ESCOLHIDA PARA A TELA DE ALTERAR
            //MUITO IMPORTANTE
            //IR NO DESIGN DO FORM DE ALTERAR E TROCAR OS 
            //DA PROPRIEDADE MODIFIERS PARA PUBLIC
            //alt.txtCodigo.Text =
            //dgvGames.CurrentRow.Cells[0].Value.ToString();
            //alt.txtNome.Text =
            //dgvGames.CurrentRow.Cells[1].Value.ToString();
            //alt.cboGenero.Text =
            //dgvGames.CurrentRow.Cells[2].Value.ToString();
            //alt.cboPlataforma.Text =
            //dgvGames.CurrentRow.Cells[3].Value.ToString();
            //alt.numJogadores.Text =
            //dgvGames.CurrentRow.Cells[4].Value.ToString();
            //alt.numQuantidade.Text =
            //dgvGames.CurrentRow.Cells[5].Value.ToString();
            //alt.mskValor.Text =
            //dgvGames.CurrentRow.Cells[6].Value.ToString();
            //alt.picGame.ImageLocation =
            //dgvGames.CurrentRow.Cells[7].Value.ToString();       

            //alt.Show();

           



        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // DataSetGameTableAdapters.TB_GAMETableAdapter taGame =
            // new DataSetGameTableAdapters.TB_GAMETableAdapter();
            //PARA CARREGAR O DATAGRID, USA-SE A PROPRIEDADE DATA
            //dgvGames.DataSource = taGame.SP_CONSULTAR_GAMES();

            DataSetBibliotecaTableAdapters.EmpLivroTableAdapter Livro =
                new DataSetBibliotecaTableAdapters.EmpLivroTableAdapter();
            dgvAlterarEmp.DataSource = Livro.SP_CONSULTA_EMPLIVRO();
        }
    }
}