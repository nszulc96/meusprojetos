using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmDelCliente : Form
    {
        public frmDelCliente()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.ClienteTableAdapter Cli = new DataSetBibliotecaTableAdapters.ClienteTableAdapter();
            dgvDelCliente.DataSource = Cli.SP_CONSULTA_CLIENTE();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {

            DataSetBibliotecaTableAdapters.ClienteTableAdapter Cliente = new DataSetBibliotecaTableAdapters.ClienteTableAdapter();
            short codigo = Convert.ToInt16(dgvDelCliente.CurrentRow.Cells[0].Value);
            Cliente.SP_DELETAR_CLIENTE(codigo);
            dgvDelCliente.DataSource = Cliente.SP_CONSULTA_CLIENTE();
            MessageBox.Show("Deletado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            
            

            
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}