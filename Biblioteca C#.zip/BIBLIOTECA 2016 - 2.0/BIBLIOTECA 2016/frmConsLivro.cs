using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmConsLivro : Form
    {
        public frmConsLivro()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            

            DataSetBibliotecaTableAdapters.LivroTableAdapter Livro =
                new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            dgvConsultarLivro.DataSource = Livro.SP_CONSULTA_LIVRO();


        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.LivroTableAdapter Livro =
                new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            dgvConsultarLivro.DataSource = Livro.SP_CONSULTA_LIVRO();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            

            frmAlterarLivro alt = new frmAlterarLivro();
            alt.txtCodigo.Text = dgvConsultarLivro.CurrentRow.Cells[0].Value.ToString();            
            alt.txtNome.Text = dgvConsultarLivro.CurrentRow.Cells[1].Value.ToString();
            alt.txtEditora.Text = dgvConsultarLivro.CurrentRow.Cells[2].Value.ToString();
            alt.txtAutor.Text = dgvConsultarLivro.CurrentRow.Cells[3].Value.ToString();
            alt.cboCategoria.Text = dgvConsultarLivro.CurrentRow.Cells[4].Value.ToString();
            alt.mskPreco.Text = dgvConsultarLivro.CurrentRow.Cells[5].Value.ToString();
            alt.picImagem.ImageLocation = dgvConsultarLivro.CurrentRow.Cells[6].Value.ToString();
            alt.Show();




            
            

        }

        private void btnGo_Click(object sender, EventArgs e)
        {
           

            DataSetBibliotecaTableAdapters.LivroTableAdapter Nome = new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            dgvConsultarLivro.DataSource = Nome.NomeLivro(txtNomeLivro.Text);
        }
    }
}