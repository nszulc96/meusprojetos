﻿namespace BIBLIOTECA_2016
{


    partial class DataSetBiblioteca
    {
    }
}

namespace BIBLIOTECA_2016.DataSetBibliotecaTableAdapters {
    
    
    public partial class ClienteTableAdapter {
    }
}
