using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmConsFunc : Form
    {
        public frmConsFunc()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter Func = new DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter();
            dgvConsultarFuncionario.DataSource = Func.ConsultarFuncion�rio();
        }

        private void btnSair_Click_1(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter Func =
                new DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter();
            dgvConsultarFuncionario.DataSource = Func.ConsultarFuncion�rio();
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {            
            
            

            frmAlterarFunc alt = new frmAlterarFunc();
            alt.txtCod.Text = dgvConsultarFuncionario.CurrentRow.Cells[0].Value.ToString();
            alt.txtNome.Text = dgvConsultarFuncionario.CurrentRow.Cells[1].Value.ToString();
            alt.txtEmail.Text = dgvConsultarFuncionario.CurrentRow.Cells[2].Value.ToString();
            alt.mskCPF.Text = dgvConsultarFuncionario.CurrentRow.Cells[3].Value.ToString();
            alt.txtSetor.Text = dgvConsultarFuncionario.CurrentRow.Cells[4].Value.ToString();
            alt.picImagem.ImageLocation = dgvConsultarFuncionario.CurrentRow.Cells[5].Value.ToString();
            alt.Show();



            
            
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            //DataSetBibliotecaTableAdapters.ClienteTableAdapter CPF = new DataSetBibliotecaTableAdapters.ClienteTableAdapter();
            //dgvConsultarClientes.DataSource = CPF.SelecionaCPF(mskCPF.Text);

            DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter CPF = new DataSetBibliotecaTableAdapters.Funcion�rioTableAdapter();
            dgvConsultarFuncionario.DataSource = CPF.cpf(mskCPF.Text);

            


        }
    }
}