namespace BIBLIOTECA_2016
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrincipal));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cadastrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcion�riosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.livrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empr�stimosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastrarEmpr�stimoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarEmpr�stimosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarFuncion�riosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarLivrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIDel = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.funcion�riosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.livrosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.empr�stimosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnAltCli = new System.Windows.Forms.Button();
            this.btnAltLivro = new System.Windows.Forms.Button();
            this.btnAltFunc = new System.Windows.Forms.Button();
            this.btnAltEmpr = new System.Windows.Forms.Button();
            this.btnApagarClientes = new System.Windows.Forms.Button();
            this.btnApagarLivros = new System.Windows.Forms.Button();
            this.btnApagarFunc = new System.Windows.Forms.Button();
            this.btnApagarEmpr = new System.Windows.Forms.Button();
            this.gpbApagar = new System.Windows.Forms.GroupBox();
            this.btnConsultarCliente = new System.Windows.Forms.Button();
            this.btnConsultarFunc = new System.Windows.Forms.Button();
            this.btnConsultarLivros = new System.Windows.Forms.Button();
            this.btnConsultarEmpres = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCadastrarCliente = new System.Windows.Forms.Button();
            this.btnCadastrarLivro = new System.Windows.Forms.Button();
            this.btnCadastrarFuncion�rio = new System.Windows.Forms.Button();
            this.btnEmprestarLivros = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.menuStrip1.SuspendLayout();
            this.gpbApagar.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastrosToolStripMenuItem,
            this.empr�stimosToolStripMenuItem,
            this.consultasToolStripMenuItem,
            this.TSMIDel,
            this.sobreToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(532, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cadastrosToolStripMenuItem
            // 
            this.cadastrosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem,
            this.funcion�riosToolStripMenuItem,
            this.livrosToolStripMenuItem});
            this.cadastrosToolStripMenuItem.Name = "cadastrosToolStripMenuItem";
            this.cadastrosToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.cadastrosToolStripMenuItem.Text = "Cadastros";
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("clientesToolStripMenuItem.Image")));
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.clientesToolStripMenuItem.Text = "Clientes";
            this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            // 
            // funcion�riosToolStripMenuItem
            // 
            this.funcion�riosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("funcion�riosToolStripMenuItem.Image")));
            this.funcion�riosToolStripMenuItem.Name = "funcion�riosToolStripMenuItem";
            this.funcion�riosToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.funcion�riosToolStripMenuItem.Text = "Funcion�rios";
            this.funcion�riosToolStripMenuItem.Click += new System.EventHandler(this.funcion�riosToolStripMenuItem_Click);
            // 
            // livrosToolStripMenuItem
            // 
            this.livrosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("livrosToolStripMenuItem.Image")));
            this.livrosToolStripMenuItem.Name = "livrosToolStripMenuItem";
            this.livrosToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.livrosToolStripMenuItem.Text = "Livros";
            this.livrosToolStripMenuItem.Click += new System.EventHandler(this.livrosToolStripMenuItem_Click);
            // 
            // empr�stimosToolStripMenuItem
            // 
            this.empr�stimosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastrarEmpr�stimoToolStripMenuItem});
            this.empr�stimosToolStripMenuItem.Name = "empr�stimosToolStripMenuItem";
            this.empr�stimosToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.empr�stimosToolStripMenuItem.Text = "Empr�stimos";
            // 
            // cadastrarEmpr�stimoToolStripMenuItem
            // 
            this.cadastrarEmpr�stimoToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cadastrarEmpr�stimoToolStripMenuItem.Image")));
            this.cadastrarEmpr�stimoToolStripMenuItem.Name = "cadastrarEmpr�stimoToolStripMenuItem";
            this.cadastrarEmpr�stimoToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.cadastrarEmpr�stimoToolStripMenuItem.Text = "Cadastrar Empr�stimo";
            this.cadastrarEmpr�stimoToolStripMenuItem.Click += new System.EventHandler(this.cadastrarEmpr�stimoToolStripMenuItem_Click);
            // 
            // consultasToolStripMenuItem
            // 
            this.consultasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultarClienteToolStripMenuItem,
            this.consultarEmpr�stimosToolStripMenuItem,
            this.consultarFuncion�riosToolStripMenuItem,
            this.consultarLivrosToolStripMenuItem});
            this.consultasToolStripMenuItem.Name = "consultasToolStripMenuItem";
            this.consultasToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
            this.consultasToolStripMenuItem.Text = "Ferramentas";
            // 
            // consultarClienteToolStripMenuItem
            // 
            this.consultarClienteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("consultarClienteToolStripMenuItem.Image")));
            this.consultarClienteToolStripMenuItem.Name = "consultarClienteToolStripMenuItem";
            this.consultarClienteToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.consultarClienteToolStripMenuItem.Text = "Consultar / Alterar Cliente";
            this.consultarClienteToolStripMenuItem.Click += new System.EventHandler(this.consultarClienteToolStripMenuItem_Click);
            // 
            // consultarEmpr�stimosToolStripMenuItem
            // 
            this.consultarEmpr�stimosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("consultarEmpr�stimosToolStripMenuItem.Image")));
            this.consultarEmpr�stimosToolStripMenuItem.Name = "consultarEmpr�stimosToolStripMenuItem";
            this.consultarEmpr�stimosToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.consultarEmpr�stimosToolStripMenuItem.Text = "Consultar/ Alterar Empr�stimos";
            this.consultarEmpr�stimosToolStripMenuItem.Click += new System.EventHandler(this.consultarEmpr�stimosToolStripMenuItem_Click);
            // 
            // consultarFuncion�riosToolStripMenuItem
            // 
            this.consultarFuncion�riosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("consultarFuncion�riosToolStripMenuItem.Image")));
            this.consultarFuncion�riosToolStripMenuItem.Name = "consultarFuncion�riosToolStripMenuItem";
            this.consultarFuncion�riosToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.consultarFuncion�riosToolStripMenuItem.Text = "Consultar / Alterar Funcion�rios";
            this.consultarFuncion�riosToolStripMenuItem.Click += new System.EventHandler(this.consultarFuncion�riosToolStripMenuItem_Click);
            // 
            // consultarLivrosToolStripMenuItem
            // 
            this.consultarLivrosToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("consultarLivrosToolStripMenuItem.Image")));
            this.consultarLivrosToolStripMenuItem.Name = "consultarLivrosToolStripMenuItem";
            this.consultarLivrosToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.consultarLivrosToolStripMenuItem.Text = "Consultar / Alterar Livros";
            this.consultarLivrosToolStripMenuItem.Click += new System.EventHandler(this.consultarLivrosToolStripMenuItem_Click);
            // 
            // TSMIDel
            // 
            this.TSMIDel.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem1,
            this.funcion�riosToolStripMenuItem1,
            this.livrosToolStripMenuItem1,
            this.empr�stimosToolStripMenuItem1});
            this.TSMIDel.Enabled = false;
            this.TSMIDel.Name = "TSMIDel";
            this.TSMIDel.Size = new System.Drawing.Size(56, 20);
            this.TSMIDel.Text = "Deletar";
            // 
            // clientesToolStripMenuItem1
            // 
            this.clientesToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("clientesToolStripMenuItem1.Image")));
            this.clientesToolStripMenuItem1.Name = "clientesToolStripMenuItem1";
            this.clientesToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.clientesToolStripMenuItem1.Text = "Clientes";
            this.clientesToolStripMenuItem1.Click += new System.EventHandler(this.clientesToolStripMenuItem1_Click);
            // 
            // funcion�riosToolStripMenuItem1
            // 
            this.funcion�riosToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("funcion�riosToolStripMenuItem1.Image")));
            this.funcion�riosToolStripMenuItem1.Name = "funcion�riosToolStripMenuItem1";
            this.funcion�riosToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.funcion�riosToolStripMenuItem1.Text = "Funcion�rios";
            this.funcion�riosToolStripMenuItem1.Click += new System.EventHandler(this.funcion�riosToolStripMenuItem1_Click);
            // 
            // livrosToolStripMenuItem1
            // 
            this.livrosToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("livrosToolStripMenuItem1.Image")));
            this.livrosToolStripMenuItem1.Name = "livrosToolStripMenuItem1";
            this.livrosToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.livrosToolStripMenuItem1.Text = "Livros";
            this.livrosToolStripMenuItem1.Click += new System.EventHandler(this.livrosToolStripMenuItem1_Click);
            // 
            // empr�stimosToolStripMenuItem1
            // 
            this.empr�stimosToolStripMenuItem1.Image = global::BIBLIOTECA_2016.Properties.Resources.msg_error;
            this.empr�stimosToolStripMenuItem1.Name = "empr�stimosToolStripMenuItem1";
            this.empr�stimosToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.empr�stimosToolStripMenuItem1.Text = "Empr�stimos";
            this.empr�stimosToolStripMenuItem1.Click += new System.EventHandler(this.empr�stimosToolStripMenuItem1_Click);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.sobreToolStripMenuItem.Text = "Sobre";
            this.sobreToolStripMenuItem.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // btnAltCli
            // 
            this.btnAltCli.Location = new System.Drawing.Point(12, 287);
            this.btnAltCli.Name = "btnAltCli";
            this.btnAltCli.Size = new System.Drawing.Size(38, 35);
            this.btnAltCli.TabIndex = 4;
            this.btnAltCli.Text = "Alterar Clientes";
            this.btnAltCli.UseVisualStyleBackColor = true;
            this.btnAltCli.Visible = false;
            this.btnAltCli.Click += new System.EventHandler(this.btnAltCli_Click);
            // 
            // btnAltLivro
            // 
            this.btnAltLivro.Location = new System.Drawing.Point(48, 287);
            this.btnAltLivro.Name = "btnAltLivro";
            this.btnAltLivro.Size = new System.Drawing.Size(37, 35);
            this.btnAltLivro.TabIndex = 4;
            this.btnAltLivro.Text = "Alterar Livros";
            this.btnAltLivro.UseVisualStyleBackColor = true;
            this.btnAltLivro.Visible = false;
            this.btnAltLivro.Click += new System.EventHandler(this.btnAltLivro_Click);
            // 
            // btnAltFunc
            // 
            this.btnAltFunc.Location = new System.Drawing.Point(12, 246);
            this.btnAltFunc.Name = "btnAltFunc";
            this.btnAltFunc.Size = new System.Drawing.Size(38, 35);
            this.btnAltFunc.TabIndex = 5;
            this.btnAltFunc.Text = "Alterar Funcion�rios";
            this.btnAltFunc.UseVisualStyleBackColor = true;
            this.btnAltFunc.Visible = false;
            this.btnAltFunc.Click += new System.EventHandler(this.btnAltFunc_Click);
            // 
            // btnAltEmpr
            // 
            this.btnAltEmpr.Location = new System.Drawing.Point(48, 246);
            this.btnAltEmpr.Name = "btnAltEmpr";
            this.btnAltEmpr.Size = new System.Drawing.Size(37, 35);
            this.btnAltEmpr.TabIndex = 6;
            this.btnAltEmpr.Text = "Alterar Empr�stimos";
            this.btnAltEmpr.UseVisualStyleBackColor = true;
            this.btnAltEmpr.Visible = false;
            this.btnAltEmpr.Click += new System.EventHandler(this.btnAltEmpr_Click);
            // 
            // btnApagarClientes
            // 
            this.btnApagarClientes.Location = new System.Drawing.Point(6, 19);
            this.btnApagarClientes.Name = "btnApagarClientes";
            this.btnApagarClientes.Size = new System.Drawing.Size(88, 35);
            this.btnApagarClientes.TabIndex = 4;
            this.btnApagarClientes.Text = "Apagar Clientes";
            this.btnApagarClientes.UseVisualStyleBackColor = true;
            this.btnApagarClientes.Click += new System.EventHandler(this.btnApagarClientes_Click);
            // 
            // btnApagarLivros
            // 
            this.btnApagarLivros.Location = new System.Drawing.Point(6, 60);
            this.btnApagarLivros.Name = "btnApagarLivros";
            this.btnApagarLivros.Size = new System.Drawing.Size(88, 35);
            this.btnApagarLivros.TabIndex = 4;
            this.btnApagarLivros.Text = "Apagar Livros";
            this.btnApagarLivros.UseVisualStyleBackColor = true;
            this.btnApagarLivros.Click += new System.EventHandler(this.btnApagarLivros_Click);
            // 
            // btnApagarFunc
            // 
            this.btnApagarFunc.Location = new System.Drawing.Point(106, 19);
            this.btnApagarFunc.Name = "btnApagarFunc";
            this.btnApagarFunc.Size = new System.Drawing.Size(88, 35);
            this.btnApagarFunc.TabIndex = 5;
            this.btnApagarFunc.Text = "Apagar Funcion�rios";
            this.btnApagarFunc.UseVisualStyleBackColor = true;
            this.btnApagarFunc.Click += new System.EventHandler(this.btnApagarFunc_Click);
            // 
            // btnApagarEmpr
            // 
            this.btnApagarEmpr.Location = new System.Drawing.Point(106, 59);
            this.btnApagarEmpr.Name = "btnApagarEmpr";
            this.btnApagarEmpr.Size = new System.Drawing.Size(88, 35);
            this.btnApagarEmpr.TabIndex = 6;
            this.btnApagarEmpr.Text = "Apagar Empr�stimos";
            this.btnApagarEmpr.UseVisualStyleBackColor = true;
            this.btnApagarEmpr.Click += new System.EventHandler(this.btnApagarEmpr_Click);
            // 
            // gpbApagar
            // 
            this.gpbApagar.Controls.Add(this.btnApagarEmpr);
            this.gpbApagar.Controls.Add(this.btnApagarFunc);
            this.gpbApagar.Controls.Add(this.btnApagarLivros);
            this.gpbApagar.Controls.Add(this.btnApagarClientes);
            this.gpbApagar.Enabled = false;
            this.gpbApagar.Location = new System.Drawing.Point(91, 303);
            this.gpbApagar.Name = "gpbApagar";
            this.gpbApagar.Size = new System.Drawing.Size(200, 100);
            this.gpbApagar.TabIndex = 3;
            this.gpbApagar.TabStop = false;
            this.gpbApagar.Text = "Apagar Registros";
            this.gpbApagar.Visible = false;
            // 
            // btnConsultarCliente
            // 
            this.btnConsultarCliente.Location = new System.Drawing.Point(6, 19);
            this.btnConsultarCliente.Name = "btnConsultarCliente";
            this.btnConsultarCliente.Size = new System.Drawing.Size(88, 35);
            this.btnConsultarCliente.TabIndex = 6;
            this.btnConsultarCliente.Text = "Consultar Clientes";
            this.btnConsultarCliente.UseVisualStyleBackColor = true;
            this.btnConsultarCliente.Click += new System.EventHandler(this.btnConsultarCliente_Click);
            // 
            // btnConsultarFunc
            // 
            this.btnConsultarFunc.Location = new System.Drawing.Point(106, 18);
            this.btnConsultarFunc.Name = "btnConsultarFunc";
            this.btnConsultarFunc.Size = new System.Drawing.Size(88, 35);
            this.btnConsultarFunc.TabIndex = 7;
            this.btnConsultarFunc.Text = "Consultar Funcion�rios";
            this.btnConsultarFunc.UseVisualStyleBackColor = true;
            this.btnConsultarFunc.Click += new System.EventHandler(this.btnConsultarFunc_Click);
            // 
            // btnConsultarLivros
            // 
            this.btnConsultarLivros.Location = new System.Drawing.Point(6, 60);
            this.btnConsultarLivros.Name = "btnConsultarLivros";
            this.btnConsultarLivros.Size = new System.Drawing.Size(88, 35);
            this.btnConsultarLivros.TabIndex = 8;
            this.btnConsultarLivros.Text = "Consultar Livros";
            this.btnConsultarLivros.UseVisualStyleBackColor = true;
            this.btnConsultarLivros.Click += new System.EventHandler(this.btnConsultarLivros_Click);
            // 
            // btnConsultarEmpres
            // 
            this.btnConsultarEmpres.Location = new System.Drawing.Point(106, 59);
            this.btnConsultarEmpres.Name = "btnConsultarEmpres";
            this.btnConsultarEmpres.Size = new System.Drawing.Size(88, 35);
            this.btnConsultarEmpres.TabIndex = 9;
            this.btnConsultarEmpres.Text = "Consultar Empr�stimos";
            this.btnConsultarEmpres.UseVisualStyleBackColor = true;
            this.btnConsultarEmpres.Click += new System.EventHandler(this.btnConsultarEmpres_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnConsultarEmpres);
            this.groupBox2.Controls.Add(this.btnConsultarLivros);
            this.groupBox2.Controls.Add(this.btnConsultarFunc);
            this.groupBox2.Controls.Add(this.btnConsultarCliente);
            this.groupBox2.Location = new System.Drawing.Point(270, 150);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Consultas";
            this.groupBox2.Visible = false;
            // 
            // btnCadastrarCliente
            // 
            this.btnCadastrarCliente.Location = new System.Drawing.Point(7, 20);
            this.btnCadastrarCliente.Name = "btnCadastrarCliente";
            this.btnCadastrarCliente.Size = new System.Drawing.Size(88, 35);
            this.btnCadastrarCliente.TabIndex = 0;
            this.btnCadastrarCliente.Text = "Cadastrar Clientes";
            this.btnCadastrarCliente.UseVisualStyleBackColor = true;
            this.btnCadastrarCliente.Click += new System.EventHandler(this.btnCadastrarCliente_Click);
            // 
            // btnCadastrarLivro
            // 
            this.btnCadastrarLivro.Location = new System.Drawing.Point(7, 59);
            this.btnCadastrarLivro.Name = "btnCadastrarLivro";
            this.btnCadastrarLivro.Size = new System.Drawing.Size(88, 35);
            this.btnCadastrarLivro.TabIndex = 1;
            this.btnCadastrarLivro.Text = "Cadastrar Livros";
            this.btnCadastrarLivro.UseVisualStyleBackColor = true;
            this.btnCadastrarLivro.Click += new System.EventHandler(this.btnCadastrarLivro_Click);
            // 
            // btnCadastrarFuncion�rio
            // 
            this.btnCadastrarFuncion�rio.Location = new System.Drawing.Point(106, 20);
            this.btnCadastrarFuncion�rio.Name = "btnCadastrarFuncion�rio";
            this.btnCadastrarFuncion�rio.Size = new System.Drawing.Size(88, 35);
            this.btnCadastrarFuncion�rio.TabIndex = 4;
            this.btnCadastrarFuncion�rio.Text = "Cadastrar Funcion�rios";
            this.btnCadastrarFuncion�rio.UseVisualStyleBackColor = true;
            this.btnCadastrarFuncion�rio.Click += new System.EventHandler(this.btnCadastrarFuncion�rio_Click);
            // 
            // btnEmprestarLivros
            // 
            this.btnEmprestarLivros.Location = new System.Drawing.Point(106, 60);
            this.btnEmprestarLivros.Name = "btnEmprestarLivros";
            this.btnEmprestarLivros.Size = new System.Drawing.Size(88, 35);
            this.btnEmprestarLivros.TabIndex = 5;
            this.btnEmprestarLivros.Text = "Empr�stimos";
            this.btnEmprestarLivros.UseVisualStyleBackColor = true;
            this.btnEmprestarLivros.Click += new System.EventHandler(this.btnEmprestarLivros_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnEmprestarLivros);
            this.groupBox1.Controls.Add(this.btnCadastrarFuncion�rio);
            this.groupBox1.Controls.Add(this.btnCadastrarLivro);
            this.groupBox1.Controls.Add(this.btnCadastrarCliente);
            this.groupBox1.Location = new System.Drawing.Point(64, 150);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastros";
            this.groupBox1.Visible = false;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(532, 457);
            this.Controls.Add(this.btnAltEmpr);
            this.Controls.Add(this.btnAltFunc);
            this.Controls.Add(this.btnAltLivro);
            this.Controls.Add(this.gpbApagar);
            this.Controls.Add(this.btnAltCli);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aplicativo Bibliotec�rio";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.gpbApagar.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cadastrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcion�riosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem livrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empr�stimosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastrarEmpr�stimoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarEmpr�stimosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarFuncion�riosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarLivrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem funcion�riosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem livrosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem empr�stimosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.Button btnAltCli;
        private System.Windows.Forms.Button btnAltLivro;
        private System.Windows.Forms.Button btnAltFunc;
        private System.Windows.Forms.Button btnAltEmpr;
        private System.Windows.Forms.Button btnApagarClientes;
        private System.Windows.Forms.Button btnApagarLivros;
        private System.Windows.Forms.Button btnApagarFunc;
        private System.Windows.Forms.Button btnApagarEmpr;
        public System.Windows.Forms.GroupBox gpbApagar;
        private System.Windows.Forms.Button btnConsultarCliente;
        private System.Windows.Forms.Button btnConsultarFunc;
        private System.Windows.Forms.Button btnConsultarLivros;
        private System.Windows.Forms.Button btnConsultarEmpres;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnCadastrarCliente;
        private System.Windows.Forms.Button btnCadastrarLivro;
        private System.Windows.Forms.Button btnCadastrarFuncion�rio;
        private System.Windows.Forms.Button btnEmprestarLivros;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.ToolStripMenuItem TSMIDel;
    }
}

