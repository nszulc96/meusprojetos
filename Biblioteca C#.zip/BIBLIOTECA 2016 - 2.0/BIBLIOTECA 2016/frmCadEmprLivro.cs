using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmCadEmprLivro : Form
    {
        public frmCadEmprLivro()
        {
            InitializeComponent();
        }

        private void btnEscolher_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao livro carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtEditora.Clear();
            txtNomeCliente.Clear();
            mskData1.Clear();
            cboFuncResponsavel.Items.Clear();
            mskData2.Clear();
            txtObs.Clear();
            if (picImagem.Image != null)
            {
                picImagem.Image.Dispose();
                picImagem.Image = null;
            }

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            

            DataSetBibliotecaTableAdapters.EmpLivroTableAdapter Emprestimo = new
                DataSetBibliotecaTableAdapters.EmpLivroTableAdapter();
            Emprestimo.SP_INSERE_EMPLIVRO(
                txtNome.Text,
                txtEditora.Text,
                txtNomeCliente.Text,
                Convert.ToDateTime(mskData1.Text),
                cboFuncResponsavel.Text,
                Convert.ToDateTime(mskData2.Text),
                txtObs.Text,
                picImagem.ImageLocation);
            MessageBox.Show("Cadastrado com Sucesso !", "Sucesso",MessageBoxButtons.OK,MessageBoxIcon.Asterisk
                );
        }

        private void frmCadEmprLivro_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSetBiblioteca2.Funcion�rio' table. You can move, or remove it, as needed.
            this.funcion�rioTableAdapter1.Fill(this.dataSetBiblioteca2.Funcion�rio);
  
            

        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            frmProcurarLivroParaEmprestimo proc = new frmProcurarLivroParaEmprestimo();

            //GUARDA A REFERENCIA(THIS) DA TELA ATUAL NA PROXIMA DE TELA
            proc.cad = this;
            proc.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmPesquisaClienteEmpLivro proc = new frmPesquisaClienteEmpLivro();
            proc.cad = this;
            proc.Show();
        }
    }
}