﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmProcurarLivroParaEmprestimo : Form
    {

        public frmCadEmprLivro cad;
        public frmProcurarLivroParaEmprestimo()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.LivroTableAdapter Livro = new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            dgvConsultarLivro.DataSource = Livro.SP_CONSULTA_LIVRO();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            DataSetBibliotecaTableAdapters.LivroTableAdapter Livro = new DataSetBibliotecaTableAdapters.LivroTableAdapter();
            dgvConsultarLivro.DataSource = Livro.SELECIONANOMELIVRO(txtNomeLivro.Text);
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            
            //alt.txtCodigo.Text = dgvConsultarLivro.CurrentRow.Cells[0].Value.ToString();

            cad.txtCodigo.Text = dgvConsultarLivro.CurrentRow.Cells[0].Value.ToString();
            cad.txtNome.Text = dgvConsultarLivro.CurrentRow.Cells[1].Value.ToString();
            cad.txtEditora.Text = dgvConsultarLivro.CurrentRow.Cells[2].Value.ToString();
            MessageBox.Show("Escolhido!", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

            cad.Show();
        }
    }
}
