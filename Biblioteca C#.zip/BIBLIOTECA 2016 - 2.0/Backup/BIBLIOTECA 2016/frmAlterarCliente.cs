using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmAlterarCliente : Form
    {
        public frmAlterarCliente()
        {
            InitializeComponent();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            // DataSetGameTableAdapters.TB_GAMETableAdapter taGame =
              //   new DataSetGameTableAdapters.TB_GAMETableAdapter();
            //PARA CARREGAR O DATAGRID, USA-SE A PROPRIEDADE DATA
            //dgvGames.DataSource = taGame.SP_CONSULTAR_GAMES();

            DataSetAltPesqClienteTableAdapters.SP_CONSULTA_CLIENTETableAdapter oi =
                new DataSetAltPesqClienteTableAdapters.SP_CONSULTA_CLIENTETableAdapter();
            dgvAlterarCliente.DataSource = oi.SP_CONSALT_CLIENTE();

          
            
        }

        private void frmAlterarCliente_Load(object sender, EventArgs e)
        {
        
        }

        private void btnAlterarCliente_Click(object sender, EventArgs e)
        {
           
            
        
        }

        
            
            
            
        }
    }

