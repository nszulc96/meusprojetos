namespace BIBLIOTECA_2016
{
    partial class frmAlterarCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSair = new System.Windows.Forms.Button();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.txtAlterarCliente = new System.Windows.Forms.TextBox();
            this.Nome = new System.Windows.Forms.Label();
            this.dgvAlterarCliente = new System.Windows.Forms.DataGridView();
            this.btnAlterarCliente = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlterarCliente)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(568, 292);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(103, 23);
            this.btnSair.TabIndex = 9;
            this.btnSair.Text = "Sair dessa tela";
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Location = new System.Drawing.Point(248, 20);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(75, 23);
            this.btnPesquisar.TabIndex = 8;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click);
            // 
            // txtAlterarCliente
            // 
            this.txtAlterarCliente.Location = new System.Drawing.Point(54, 20);
            this.txtAlterarCliente.Multiline = true;
            this.txtAlterarCliente.Name = "txtAlterarCliente";
            this.txtAlterarCliente.Size = new System.Drawing.Size(187, 24);
            this.txtAlterarCliente.TabIndex = 7;
            // 
            // Nome
            // 
            this.Nome.AutoSize = true;
            this.Nome.Location = new System.Drawing.Point(12, 24);
            this.Nome.Name = "Nome";
            this.Nome.Size = new System.Drawing.Size(35, 13);
            this.Nome.TabIndex = 6;
            this.Nome.Text = "Nome";
            // 
            // dgvAlterarCliente
            // 
            this.dgvAlterarCliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlterarCliente.Location = new System.Drawing.Point(12, 64);
            this.dgvAlterarCliente.Name = "dgvAlterarCliente";
            this.dgvAlterarCliente.ReadOnly = true;
            this.dgvAlterarCliente.Size = new System.Drawing.Size(659, 222);
            this.dgvAlterarCliente.TabIndex = 5;
            // 
            // btnAlterarCliente
            // 
            this.btnAlterarCliente.Location = new System.Drawing.Point(15, 292);
            this.btnAlterarCliente.Name = "btnAlterarCliente";
            this.btnAlterarCliente.Size = new System.Drawing.Size(91, 23);
            this.btnAlterarCliente.TabIndex = 10;
            this.btnAlterarCliente.Text = "Alterar Dados";
            this.btnAlterarCliente.UseVisualStyleBackColor = true;
            this.btnAlterarCliente.Click += new System.EventHandler(this.btnAlterarCliente_Click);
            // 
            // frmAlterarCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 334);
            this.Controls.Add(this.btnAlterarCliente);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.txtAlterarCliente);
            this.Controls.Add(this.Nome);
            this.Controls.Add(this.dgvAlterarCliente);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmAlterarCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alterar Clientes";
            this.Load += new System.EventHandler(this.frmAlterarCliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlterarCliente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button btnSair;
        public System.Windows.Forms.Button btnPesquisar;
        public System.Windows.Forms.TextBox txtAlterarCliente;
        public System.Windows.Forms.Label Nome;
        public System.Windows.Forms.DataGridView dgvAlterarCliente;
        public System.Windows.Forms.Button btnAlterarCliente;

    }
}