using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmCadCliente : Form
    {
        public frmCadCliente()
        {
            InitializeComponent();
        }

        private void btnEscolher_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao cliente carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void picImagem_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            mskTelefone.Clear();
            mskCelular.Clear();
            txtEndereco.Clear();
            txtEmail.Clear();
            mskCPF.Clear();
            if (picImagem.Image != null)
            {
                picImagem.Image.Dispose();
                picImagem.Image = null;
            }


        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            //DataSetGameTableAdapters.FUNCIONARIOTableAdapter Func = new DataSetGameTableAdapters.FUNCIONARIOTableAdapter();
            //Func.SP_INSERIR_FUNCIONARIO(
            //mskCPF.Text,
            //txtNome.Text,
            //Convert.ToDateTime(mskData.Text),
            //Convert.ToDateTime(dtpDataAdm.Text),
            //cboCargo.Text);
            //MessageBox.Show("Cadastrado com Sucesso");

            DataSetInserirClientesTableAdapters.QueriesTableAdapter Cliente = new DataSetInserirClientesTableAdapters.QueriesTableAdapter();
            Cliente.INSERIRCLIENTE(txtNome.Text,
                txtNome.Text,
                mskTelefone.Text,
                mskCelular.Text,
                txtEndereco.Text,
                txtEmail.Text,
                mskCPF.Text,
                txtEmail.Text);
            MessageBox.Show("Cadastrado com sucesso");
        }
    }
}