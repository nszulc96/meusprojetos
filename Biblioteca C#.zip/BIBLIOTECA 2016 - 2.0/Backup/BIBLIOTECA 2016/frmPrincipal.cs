using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnCadastrarCliente_Click(object sender, EventArgs e)
        {
            frmCadCliente CadCli = new frmCadCliente();
            CadCli.Show();
        }

        private void btnCadastrarFuncion�rio_Click(object sender, EventArgs e)
        {
            frmCadFunc CadFunc = new frmCadFunc();
            CadFunc.Show();
        }

        private void btnCadastrarLivro_Click(object sender, EventArgs e)
        {
            frmCadLivro CadLivro = new frmCadLivro();
            CadLivro.Show();
        }

        private void btnEmprestarLivros_Click(object sender, EventArgs e)
        {
            frmCadEmprLivro Emp = new frmCadEmprLivro();
            Emp.Show();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void btnAltCli_Click(object sender, EventArgs e)
        {
            frmAlterarCliente AltCLi = new frmAlterarCliente();
            AltCLi.Show();
        }

        private void btnAltFunc_Click(object sender, EventArgs e)
        {
            frmAlterarFunc func = new frmAlterarFunc();
            func.Show();
        }

        private void btnAltLivro_Click(object sender, EventArgs e)
        {
            frmAlterarLivro at = new frmAlterarLivro();
            at.Show();
        }

        private void btnAltEmpr_Click(object sender, EventArgs e)
        {
            frmAlterarEmp oi = new frmAlterarEmp();
            oi.Show();
        }

        private void btnApagarClientes_Click(object sender, EventArgs e)
        {
            frmDelCliente oi = new frmDelCliente();
            oi.Show();
        }

        private void btnApagarFunc_Click(object sender, EventArgs e)
        {
            frmDelFunc oi = new frmDelFunc();
            oi.Show();
        }

        private void btnApagarLivros_Click(object sender, EventArgs e)
        {
            frmDelLivro DelLivro = new frmDelLivro();
            DelLivro.Show();
        }

        private void btnApagarEmpr_Click(object sender, EventArgs e)
        {
            frmDelEmp delemp = new frmDelEmp();
            delemp.Show();
        }

        private void btnConsultarCliente_Click(object sender, EventArgs e)
        {
            frmConsCliente oi = new frmConsCliente();
            oi.Show();

        }

        private void btnConsultarLivros_Click(object sender, EventArgs e)
        {
            frmConsLivro oi = new frmConsLivro();
            oi.Show();

        }

        private void btnConsultarFunc_Click(object sender, EventArgs e)
        {
            frmConsFunc oi = new frmConsFunc();
            oi.Show();

        }

        private void btnConsultarEmpres_Click(object sender, EventArgs e)
        {
            frmConsEmprestimo oi = new frmConsEmprestimo();
            oi.Show();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Voc� est� saindo do programa!", "Sa�da", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            Application.Exit();
        }
    }
}