namespace BIBLIOTECA_2016
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnCadastrarCliente = new System.Windows.Forms.Button();
            this.btnCadastrarLivro = new System.Windows.Forms.Button();
            this.btnCadastrarFuncion�rio = new System.Windows.Forms.Button();
            this.btnEmprestarLivros = new System.Windows.Forms.Button();
            this.btnConsultarCliente = new System.Windows.Forms.Button();
            this.btnConsultarFunc = new System.Windows.Forms.Button();
            this.btnConsultarLivros = new System.Windows.Forms.Button();
            this.btnConsultarEmpres = new System.Windows.Forms.Button();
            this.btnAltCli = new System.Windows.Forms.Button();
            this.btnAltFunc = new System.Windows.Forms.Button();
            this.btnAltLivro = new System.Windows.Forms.Button();
            this.btnAltEmpr = new System.Windows.Forms.Button();
            this.btnApagarClientes = new System.Windows.Forms.Button();
            this.btnApagarLivros = new System.Windows.Forms.Button();
            this.btnApagarFunc = new System.Windows.Forms.Button();
            this.btnApagarEmpr = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnEmprestarLivros);
            this.groupBox1.Controls.Add(this.btnCadastrarFuncion�rio);
            this.groupBox1.Controls.Add(this.btnCadastrarLivro);
            this.groupBox1.Controls.Add(this.btnCadastrarCliente);
            this.groupBox1.Location = new System.Drawing.Point(48, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cadastros";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnConsultarEmpres);
            this.groupBox2.Controls.Add(this.btnConsultarLivros);
            this.groupBox2.Controls.Add(this.btnConsultarFunc);
            this.groupBox2.Controls.Add(this.btnConsultarCliente);
            this.groupBox2.Location = new System.Drawing.Point(279, 46);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Consultas";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnAltEmpr);
            this.groupBox3.Controls.Add(this.btnAltLivro);
            this.groupBox3.Controls.Add(this.btnAltFunc);
            this.groupBox3.Controls.Add(this.btnAltCli);
            this.groupBox3.Location = new System.Drawing.Point(48, 178);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 100);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Altera��es";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnApagarEmpr);
            this.groupBox4.Controls.Add(this.btnApagarFunc);
            this.groupBox4.Controls.Add(this.btnApagarLivros);
            this.groupBox4.Controls.Add(this.btnApagarClientes);
            this.groupBox4.Location = new System.Drawing.Point(279, 178);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 100);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Apagar Registros";
            // 
            // btnCadastrarCliente
            // 
            this.btnCadastrarCliente.Location = new System.Drawing.Point(7, 20);
            this.btnCadastrarCliente.Name = "btnCadastrarCliente";
            this.btnCadastrarCliente.Size = new System.Drawing.Size(88, 35);
            this.btnCadastrarCliente.TabIndex = 0;
            this.btnCadastrarCliente.Text = "Cadastrar Clientes";
            this.btnCadastrarCliente.UseVisualStyleBackColor = true;
            this.btnCadastrarCliente.Click += new System.EventHandler(this.btnCadastrarCliente_Click);
            // 
            // btnCadastrarLivro
            // 
            this.btnCadastrarLivro.Location = new System.Drawing.Point(7, 59);
            this.btnCadastrarLivro.Name = "btnCadastrarLivro";
            this.btnCadastrarLivro.Size = new System.Drawing.Size(88, 35);
            this.btnCadastrarLivro.TabIndex = 1;
            this.btnCadastrarLivro.Text = "Cadastrar Livros";
            this.btnCadastrarLivro.UseVisualStyleBackColor = true;
            this.btnCadastrarLivro.Click += new System.EventHandler(this.btnCadastrarLivro_Click);
            // 
            // btnCadastrarFuncion�rio
            // 
            this.btnCadastrarFuncion�rio.Location = new System.Drawing.Point(106, 20);
            this.btnCadastrarFuncion�rio.Name = "btnCadastrarFuncion�rio";
            this.btnCadastrarFuncion�rio.Size = new System.Drawing.Size(88, 35);
            this.btnCadastrarFuncion�rio.TabIndex = 4;
            this.btnCadastrarFuncion�rio.Text = "Cadastrar Funcion�rios";
            this.btnCadastrarFuncion�rio.UseVisualStyleBackColor = true;
            this.btnCadastrarFuncion�rio.Click += new System.EventHandler(this.btnCadastrarFuncion�rio_Click);
            // 
            // btnEmprestarLivros
            // 
            this.btnEmprestarLivros.Location = new System.Drawing.Point(106, 60);
            this.btnEmprestarLivros.Name = "btnEmprestarLivros";
            this.btnEmprestarLivros.Size = new System.Drawing.Size(88, 35);
            this.btnEmprestarLivros.TabIndex = 5;
            this.btnEmprestarLivros.Text = "Empr�stimos";
            this.btnEmprestarLivros.UseVisualStyleBackColor = true;
            this.btnEmprestarLivros.Click += new System.EventHandler(this.btnEmprestarLivros_Click);
            // 
            // btnConsultarCliente
            // 
            this.btnConsultarCliente.Location = new System.Drawing.Point(6, 19);
            this.btnConsultarCliente.Name = "btnConsultarCliente";
            this.btnConsultarCliente.Size = new System.Drawing.Size(88, 35);
            this.btnConsultarCliente.TabIndex = 6;
            this.btnConsultarCliente.Text = "Consultar Clientes";
            this.btnConsultarCliente.UseVisualStyleBackColor = true;
            this.btnConsultarCliente.Click += new System.EventHandler(this.btnConsultarCliente_Click);
            // 
            // btnConsultarFunc
            // 
            this.btnConsultarFunc.Location = new System.Drawing.Point(106, 18);
            this.btnConsultarFunc.Name = "btnConsultarFunc";
            this.btnConsultarFunc.Size = new System.Drawing.Size(88, 35);
            this.btnConsultarFunc.TabIndex = 7;
            this.btnConsultarFunc.Text = "Consultar Funcion�rios";
            this.btnConsultarFunc.UseVisualStyleBackColor = true;
            this.btnConsultarFunc.Click += new System.EventHandler(this.btnConsultarFunc_Click);
            // 
            // btnConsultarLivros
            // 
            this.btnConsultarLivros.Location = new System.Drawing.Point(6, 60);
            this.btnConsultarLivros.Name = "btnConsultarLivros";
            this.btnConsultarLivros.Size = new System.Drawing.Size(88, 35);
            this.btnConsultarLivros.TabIndex = 8;
            this.btnConsultarLivros.Text = "Consultar Livros";
            this.btnConsultarLivros.UseVisualStyleBackColor = true;
            this.btnConsultarLivros.Click += new System.EventHandler(this.btnConsultarLivros_Click);
            // 
            // btnConsultarEmpres
            // 
            this.btnConsultarEmpres.Location = new System.Drawing.Point(106, 59);
            this.btnConsultarEmpres.Name = "btnConsultarEmpres";
            this.btnConsultarEmpres.Size = new System.Drawing.Size(88, 35);
            this.btnConsultarEmpres.TabIndex = 9;
            this.btnConsultarEmpres.Text = "Consultar Empr�stimos";
            this.btnConsultarEmpres.UseVisualStyleBackColor = true;
            this.btnConsultarEmpres.Click += new System.EventHandler(this.btnConsultarEmpres_Click);
            // 
            // btnAltCli
            // 
            this.btnAltCli.Location = new System.Drawing.Point(7, 19);
            this.btnAltCli.Name = "btnAltCli";
            this.btnAltCli.Size = new System.Drawing.Size(88, 35);
            this.btnAltCli.TabIndex = 4;
            this.btnAltCli.Text = "Alterar Clientes";
            this.btnAltCli.UseVisualStyleBackColor = true;
            this.btnAltCli.Click += new System.EventHandler(this.btnAltCli_Click);
            // 
            // btnAltFunc
            // 
            this.btnAltFunc.Location = new System.Drawing.Point(106, 19);
            this.btnAltFunc.Name = "btnAltFunc";
            this.btnAltFunc.Size = new System.Drawing.Size(88, 35);
            this.btnAltFunc.TabIndex = 5;
            this.btnAltFunc.Text = "Alterar Funcion�rios";
            this.btnAltFunc.UseVisualStyleBackColor = true;
            this.btnAltFunc.Click += new System.EventHandler(this.btnAltFunc_Click);
            // 
            // btnAltLivro
            // 
            this.btnAltLivro.Location = new System.Drawing.Point(7, 59);
            this.btnAltLivro.Name = "btnAltLivro";
            this.btnAltLivro.Size = new System.Drawing.Size(88, 35);
            this.btnAltLivro.TabIndex = 4;
            this.btnAltLivro.Text = "Alterar Livros";
            this.btnAltLivro.UseVisualStyleBackColor = true;
            this.btnAltLivro.Click += new System.EventHandler(this.btnAltLivro_Click);
            // 
            // btnAltEmpr
            // 
            this.btnAltEmpr.Location = new System.Drawing.Point(106, 59);
            this.btnAltEmpr.Name = "btnAltEmpr";
            this.btnAltEmpr.Size = new System.Drawing.Size(88, 35);
            this.btnAltEmpr.TabIndex = 6;
            this.btnAltEmpr.Text = "Alterar Empr�stimos";
            this.btnAltEmpr.UseVisualStyleBackColor = true;
            this.btnAltEmpr.Click += new System.EventHandler(this.btnAltEmpr_Click);
            // 
            // btnApagarClientes
            // 
            this.btnApagarClientes.Location = new System.Drawing.Point(6, 19);
            this.btnApagarClientes.Name = "btnApagarClientes";
            this.btnApagarClientes.Size = new System.Drawing.Size(88, 35);
            this.btnApagarClientes.TabIndex = 4;
            this.btnApagarClientes.Text = "Apagar Clientes";
            this.btnApagarClientes.UseVisualStyleBackColor = true;
            this.btnApagarClientes.Click += new System.EventHandler(this.btnApagarClientes_Click);
            // 
            // btnApagarLivros
            // 
            this.btnApagarLivros.Location = new System.Drawing.Point(6, 60);
            this.btnApagarLivros.Name = "btnApagarLivros";
            this.btnApagarLivros.Size = new System.Drawing.Size(88, 35);
            this.btnApagarLivros.TabIndex = 4;
            this.btnApagarLivros.Text = "Apagar Livros";
            this.btnApagarLivros.UseVisualStyleBackColor = true;
            this.btnApagarLivros.Click += new System.EventHandler(this.btnApagarLivros_Click);
            // 
            // btnApagarFunc
            // 
            this.btnApagarFunc.Location = new System.Drawing.Point(106, 19);
            this.btnApagarFunc.Name = "btnApagarFunc";
            this.btnApagarFunc.Size = new System.Drawing.Size(88, 35);
            this.btnApagarFunc.TabIndex = 5;
            this.btnApagarFunc.Text = "Apagar Funcion�rios";
            this.btnApagarFunc.UseVisualStyleBackColor = true;
            this.btnApagarFunc.Click += new System.EventHandler(this.btnApagarFunc_Click);
            // 
            // btnApagarEmpr
            // 
            this.btnApagarEmpr.Location = new System.Drawing.Point(106, 59);
            this.btnApagarEmpr.Name = "btnApagarEmpr";
            this.btnApagarEmpr.Size = new System.Drawing.Size(88, 35);
            this.btnApagarEmpr.TabIndex = 6;
            this.btnApagarEmpr.Text = "Apagar Empr�stimos";
            this.btnApagarEmpr.UseVisualStyleBackColor = true;
            this.btnApagarEmpr.Click += new System.EventHandler(this.btnApagarEmpr_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(210, 299);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(100, 23);
            this.btnSair.TabIndex = 4;
            this.btnSair.Text = "Sair do Programa";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 334);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aplicativo Bibliotec�rio";
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnEmprestarLivros;
        private System.Windows.Forms.Button btnCadastrarFuncion�rio;
        private System.Windows.Forms.Button btnCadastrarLivro;
        private System.Windows.Forms.Button btnCadastrarCliente;
        private System.Windows.Forms.Button btnConsultarEmpres;
        private System.Windows.Forms.Button btnConsultarLivros;
        private System.Windows.Forms.Button btnConsultarFunc;
        private System.Windows.Forms.Button btnConsultarCliente;
        private System.Windows.Forms.Button btnAltFunc;
        private System.Windows.Forms.Button btnAltCli;
        private System.Windows.Forms.Button btnAltEmpr;
        private System.Windows.Forms.Button btnAltLivro;
        private System.Windows.Forms.Button btnApagarEmpr;
        private System.Windows.Forms.Button btnApagarFunc;
        private System.Windows.Forms.Button btnApagarLivros;
        private System.Windows.Forms.Button btnApagarClientes;
        private System.Windows.Forms.Button btnSair;
    }
}

