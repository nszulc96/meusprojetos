using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmConsCliente : Form
    {
        public frmConsCliente()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //DataSetGameTableAdapters.TB_GAMETableAdapter taGame =
            //new DataSetGameTableAdapters.TB_GAMETableAdapter();
            //PARA CARREGAR O DATAGRID, USA-SE A PROPRIEDADE DATA
            //dgvGames.DataSource = taGame.SP_CONSULTAR_GAMES();

            DataSetConsultarClientesTableAdapters.SP_CONSULTA_CLIENTETableAdapter Cli = new
                DataSetConsultarClientesTableAdapters.SP_CONSULTA_CLIENTETableAdapter();
            dgvConsultarClientes.DataSource = Cli.SP_CONSULTA_CLIENTE();
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}