using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmDelLivro : Form
    {
        public frmDelLivro()
        {
            InitializeComponent();
        }
    }
}