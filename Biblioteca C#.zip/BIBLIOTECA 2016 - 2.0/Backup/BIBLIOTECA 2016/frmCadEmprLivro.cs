using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BIBLIOTECA_2016
{
    public partial class frmCadEmprLivro : Form
    {
        public frmCadEmprLivro()
        {
            InitializeComponent();
        }

        private void btnEscolher_Click(object sender, EventArgs e)
        {
            OpenFileDialog arquivo = new OpenFileDialog();
            arquivo.ShowDialog();

            picImagem.ImageLocation = arquivo.FileName;
            MessageBox.Show("Imagem referente ao livro carregada com sucesso", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtEditora.Clear();
            mskData1.Clear();
            txtFunc.Clear();
            mskData2.Clear();
            txtObs.Clear();
            if (picImagem.Image != null)
            {
                picImagem.Image.Dispose();
                picImagem.Image = null;
            }

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }
    }
}